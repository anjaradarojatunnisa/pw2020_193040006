
<!DOCTYPE html>
<html>
<head>
	<title>index</title>
	<link rel="stylesheet" type="text/css" href="index.css">
</head>
<body>
	
	<!-- bagian header template -->
	<header>
		<h1 class="judul"><marquee>wilujeung sumping di index sederhana pisan</marquee></h1>
		<p class="deskripsi">TUGAS .</p>
	</header>
	<!-- akhir bagian header template -->
	
	<div class="wrap">
		<!-- bagian menu		 -->
		<nav class="menu">
			<ul>
				<li>
					<a href="#">Home</a>
				</li>
				<li>
					<a href="#">Tugas</a>
				</li>
				<li>
					<a href="https://api.whatsapp.com/send?phone=6289663218711">Kontak</a>
				</li>
			</ul>
		</nav>
		<!-- akhir bagian menu -->
 
		<!-- bagian sidebar  -->
		<aside class="sidebar">
			<div class="widget">
				<h2>cari tentang aku</h2>
				<p>cari tau tentang aku <a target="_blank" href="https://about.com/anjaradarojatunnisa">aboutme</a>..</p>
			</div>
			<div class="widget">
				<h2>follow aku yaa..</h2>
				<p>teman teman follow aku yaa <a target="_blank" href="https://www.instagram.com/anzharadnisa/?hl=id">www.instagram.com</a>.</p>
			</div>
		</aside>
		<!-- akhir bagian sidebar  -->
 
		<!-- bagian konten Blog -->
		<div class="blog">
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>anjara darojatun nisa</b>
				</div>
				<!-- <img src="css.jpg"> -->
				<h1> INDEX KULIAH </h1>
				<hr>
				<p>
					tugas latihan pertemuan ke4,akang jangan lupa makan hehehe,maaf becanda kang:)
				</p>				
				<a href="kuliah" class="continue-lendo">Selengkapnya → </a>
			</div>			
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>anjara darojatun nisa</b>
				</div>
				<!-- <img src="css.jpg"> -->
				<h1> INDEX PRAKTIKUM </h1>
				<hr>
				<p>
					tugas latihan pertemuan ke4,akang jangan lupa makan hehehe,maaf becanda kang:)
				</p>				
				<a href="praktikum" class="continue-lendo">Selengkapnya → </a>
			</div>			
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>anjara darojatun nisa</b>
				</div>
				<!-- <img src="css.jpg"> -->
				<h1> INDEX TUGAS BESAR </h1>
				<hr>
				<p>
					tugas latihan pertemuan ke4,akang jangan lupa makan hehehe,maaf becanda kang:)
				</p>				
				<a href="tubes" class="continue-lendo">Selengkapnya → </a>
			</div>			
				
			<div class="conteudo">
				<div class="post-info">
					Di Posting Oleh <b>anjara darojatun nisa</b>
				</div>
		<!-- akhir bagian konten Blog -->
	</div>
 
</body>
</html>
